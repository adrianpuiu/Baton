/**
 * BPMN 2.0 XML → ProcessAST importer.
 *
 * This is the build that turns Baton from a closed-loop tool (generate PiperFlow,
 * check PiperFlow) into an open one: ingest ANY BPMN 2.0 export — from Camunda,
 * Signavio, Appian, or Baton's own emitter — and feed it to the soundness checker
 * (and, downstream, the renderer/compiler). The loop opens the moment you can
 * point Baton at a process someone already has, not just one it produced.
 *
 * Scope (honest, for v1): extracts the control-flow structure — elements,
 * sequence flows, lanes, pools, task sub-types. That's exactly what the
 * soundness checker needs. It deliberately does NOT enforce PiperFlow's strict
 * authoring rules (single start, no orphans): real-world BPMN is messier than
 * we let authors be, and an intake tool must be permissive. The data layer
 * (ioSpec) is not reconstructed (soundness is control-flow only anyway).
 * Multi-process files (one collaboration, several participant processes) take
 * the first referenced process in v1 — flagged as a limitation.
 */
import { XMLParser } from 'fast-xml-parser';
/** BPMN element tag → our category/variant (+optional taskType). */
const ELEMENT_MAP = {
    startEvent: { category: 'event', variant: 'start' },
    endEvent: { category: 'event', variant: 'end' },
    intermediateCatchEvent: { category: 'event', variant: 'intermediate' },
    intermediateThrowEvent: { category: 'event', variant: 'intermediate' },
    boundaryEvent: { category: 'event', variant: 'intermediate' },
    task: { category: 'activity', variant: 'task' },
    serviceTask: { category: 'activity', variant: 'task', taskType: 'service' },
    userTask: { category: 'activity', variant: 'task', taskType: 'user' },
    businessRuleTask: { category: 'activity', variant: 'task', taskType: 'businessRule' },
    sendTask: { category: 'activity', variant: 'task', taskType: 'send' },
    receiveTask: { category: 'activity', variant: 'task', taskType: 'receive' },
    manualTask: { category: 'activity', variant: 'task', taskType: 'manual' },
    scriptTask: { category: 'activity', variant: 'task', taskType: 'script' },
    subProcess: { category: 'activity', variant: 'subprocess' },
    callActivity: { category: 'activity', variant: 'subprocess' },
    transaction: { category: 'activity', variant: 'subprocess' },
    exclusiveGateway: { category: 'gateway', variant: 'exclusive' },
    parallelGateway: { category: 'gateway', variant: 'parallel' },
    inclusiveGateway: { category: 'gateway', variant: 'inclusive' },
    eventBasedGateway: { category: 'gateway', variant: 'event' },
    complexGateway: { category: 'gateway', variant: 'exclusive' }, // approximated
};
/** Coerce a fast-xml-parser node to an array (single child → [child], missing → []). */
function asArray(x) {
    if (x === undefined || x === null)
        return [];
    return Array.isArray(x) ? x : [x];
}
/** Strip a BPMN namespace prefix ('bpmn:task' → 'task'). */
const localName = (qname) => qname.replace(/^[^:]+:/, '');
export class BpmnImportError extends Error {
}
/**
 * Parse BPMN 2.0 XML into a ProcessAST suitable for the soundness checker.
 * Throws BpmnImportError on fundamentally un-parseable input.
 */
export function importBpmn(xml) {
    let parsed;
    try {
        parsed = new XMLParser({
            ignoreAttributes: false,
            attributeNamePrefix: '@_',
            // Keep element/attribute names verbatim (namespaces matter for BPMN).
            removeNSPrefix: false,
            trimValues: true,
        }).parse(xml);
    }
    catch (e) {
        throw new BpmnImportError(`Could not parse XML: ${e.message}`);
    }
    const defs = parsed['bpmn:definitions'];
    if (!defs)
        throw new BpmnImportError('Not a BPMN file: no <bpmn:definitions> root.');
    // Collect all processes (one per pool in a collaboration, or a single process).
    const processes = asArray(defs['bpmn:process']);
    if (processes.length === 0)
        throw new BpmnImportError('No <bpmn:process> found.');
    // participant → pool name, keyed by processRef.
    const collaboration = asArray(defs['bpmn:collaboration'])[0];
    const poolByProcessRef = new Map();
    for (const p of asArray(collaboration?.['bpmn:participant'])) {
        const ref = p['@_processRef'];
        const name = p['@_name'] || p['@_id'] || 'Pool';
        if (ref)
            poolByProcessRef.set(ref, name);
    }
    // v1 limitation: handle the first process. (Multi-process collaboration merge
    // is a real feature but out of scope for the soundness MVP.)
    const process = processes[0];
    const processId = process['@_id'] ?? 'process';
    const title = process['@_name'] ?? processId;
    const poolName = poolByProcessRef.get(processId);
    // Lane map: nodeId → lane name. Built from laneSet/lane/flowNodeRef.
    const laneOfNode = new Map();
    const lanes = [];
    const laneSets = asArray(process['bpmn:laneSet'] ?? undefined);
    for (const ls of laneSets) {
        for (const lane of asArray(ls['bpmn:lane'] ?? undefined)) {
            const laneName = lane['@_name'] ?? lane['@_id'] ?? 'Lane';
            lanes.push({ name: laneName, ...(poolName ? { pool: poolName } : {}) });
            for (const ref of asArray(lane['bpmn:flowNodeRef'])) {
                laneOfNode.set(ref, laneName);
            }
        }
    }
    // If the process had no lanes, every element lands in a synthetic default lane.
    const DEFAULT_LANE = poolName ?? 'Process';
    if (lanes.length === 0)
        lanes.push({ name: DEFAULT_LANE, ...(poolName ? { pool: poolName } : {}) });
    // Walk the process's direct children once, partitioning by tag.
    const elements = [];
    const knownElementIds = new Set();
    // Boundary events attach to activities via attachedToRef. We collect them here
    // and resolve them after the element loop (the host activity must exist).
    const boundaryEvents = [];
    const detectTrigger = (node) => {
        // A boundary carries exactly one event definition child. Detect in priority
        // order; absence of any definition means a "none" boundary (rare) → skip.
        if (node['bpmn:timerEventDefinition'] || node['timerEventDefinition']) {
            const td = (node['bpmn:timerEventDefinition'] ?? node['timerEventDefinition']);
            const expr = (td?.['bpmn:timeDuration'] ?? td?.['timeDuration'] ?? td?.['bpmn:timeDate'] ?? td?.['timeDate']);
            const exprText = expr?.['#text'] ?? expr?.['@_xsi:type'];
            return { type: 'timer', ...(exprText ? { code: exprText } : {}) };
        }
        if (node['bpmn:escalationEventDefinition'] || node['escalationEventDefinition']) {
            const ed = (node['bpmn:escalationEventDefinition'] ?? node['escalationEventDefinition']);
            const ref = ed?.['@_escalationRef'];
            return { type: 'escalation', ...(ref ? { code: ref } : {}) };
        }
        if (node['bpmn:messageEventDefinition'] || node['messageEventDefinition'])
            return { type: 'message' };
        if (node['bpmn:signalEventDefinition'] || node['signalEventDefinition'])
            return { type: 'signal' };
        if (node['bpmn:errorEventDefinition'] || node['errorEventDefinition'])
            return { type: 'error' };
        if (node['bpmn:conditionalEventDefinition'] || node['conditionalEventDefinition'])
            return { type: 'conditional' };
        return undefined;
    };
    for (const [key, value] of Object.entries(process)) {
        if (key.startsWith('@_'))
            continue; // attribute
        const tag = localName(key);
        const mapping = ELEMENT_MAP[tag];
        if (!mapping)
            continue; // sequenceFlow, ioSpecification, dataObject, etc. handled separately
        for (const node of asArray(value)) {
            const id = node['@_id'];
            if (!id)
                continue; // can't reference a node without an id
            const lane = laneOfNode.get(id) ?? DEFAULT_LANE;
            const nameAttr = node['@_name'];
            const label = mapping.variant === 'start' || mapping.variant === 'end'
                ? mapping.variant.charAt(0).toUpperCase() + mapping.variant.slice(1)
                : (nameAttr ?? id);
            // Boundary events: a special case. They are NOT first-class flow elements
            // in our AST (they attach to an activity). Collect them for the stall /
            // escalation checks instead of emitting an element.
            if (tag === 'boundaryEvent') {
                const attachedTo = node['@_attachedToRef'];
                const interrupting = node['@_cancelActivity'] !== 'false'; // default true
                const trigger = detectTrigger(node);
                if (attachedTo && trigger) {
                    boundaryEvents.push({
                        id,
                        attachedTo,
                        type: trigger.type,
                        interrupting,
                        ...(trigger.code ? { code: trigger.code } : {}),
                    });
                }
                continue;
            }
            elements.push({
                id,
                label,
                lane,
                category: mapping.category,
                variant: mapping.variant,
                ...(mapping.taskType ? { taskType: mapping.taskType } : {}),
                ...(poolName ? { pool: poolName } : {}),
            });
            knownElementIds.add(id);
        }
    }
    // Sequence flows → edges. Drop refs that don't resolve to a known element
    // (dangling edges are noise for soundness; keep the structure honest).
    const edges = [];
    for (const sf of asArray(process['bpmn:sequenceFlow'] ?? undefined)) {
        const from = sf['@_sourceRef'];
        const to = sf['@_targetRef'];
        if (!from || !to)
            continue;
        // Boundary events CAN be sequence-flow sources (the escalation branch). They
        // are not in knownElementIds, so allow from/to to reference a boundary by id.
        const fromOk = knownElementIds.has(from) || boundaryEvents.some((b) => b.id === from);
        const toOk = knownElementIds.has(to) || boundaryEvents.some((b) => b.id === to);
        if (!fromOk || !toOk)
            continue;
        const name = sf['@_name'];
        edges.push({ from, to, ...(name ? { label: name } : {}) });
    }
    // Process-level escalation definitions (escalationRef targets).
    const escalations = [];
    for (const esc of asArray(defs['bpmn:escalation'] ?? undefined)) {
        const id = esc['@_id'] ?? `escalation-${escalations.length}`;
        const code = esc['@_escalationCode'];
        escalations.push({ id, ...(code ? { code } : {}) });
    }
    // Attach boundary events to their host activities so the stall check has the
    // context locally. Also keep the flat list on the AST for escalation-coverage.
    const boundaryByHost = new Map();
    for (const b of boundaryEvents) {
        const list = boundaryByHost.get(b.attachedTo) ?? [];
        list.push(b);
        boundaryByHost.set(b.attachedTo, list);
    }
    for (const el of elements) {
        const hosted = boundaryByHost.get(el.id);
        if (hosted)
            el.boundaryEvents = hosted;
    }
    return {
        title,
        lanes,
        elements,
        edges,
        dataObjects: [], // control-flow import only; data layer out of scope for v1
        ...(boundaryEvents.length ? { boundaryEvents } : {}),
        ...(escalations.length ? { escalations } : {}),
    };
}

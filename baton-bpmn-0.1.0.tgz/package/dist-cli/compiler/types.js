/**
 * The PiperFlow AST.
 *
 * The DSL is the single source of truth. Consumers of this AST:
 *   - render  → PNG / SVG / BPMN-XML (via processpiper + the direct AST emitter)
 *   - compile → a runnable Flue workflow (lanes→agents, tasks→calls,
 *               gateways→ conditional / parallel branches)
 *
 * Element taxonomy follows the official ProcessPiper grammar:
 *   events    : start, end, timer, intermediate, message, signal, conditional, link
 *   activities: task (default), subprocess
 *   gateways  : exclusive (default), parallel, inclusive, event
 *
 * The data layer (DataObject + ProcessElement.ioSpec) is the seed of
 * BPMN Executable conformance: it carries what each task consumes/produces so
 * the BPMN emitter can produce ioSpecification + data associations, and so a
 * future runtime evaluator can self-assemble behaviour against process data
 * (the SAIL move).
 */
/** Convenience guards used by the compiler and executor. */
export const isStart = (e) => e.category === 'event' && e.variant === 'start';
export const isEnd = (e) => e.category === 'event' && e.variant === 'end';
export const isGateway = (e) => e.category === 'gateway';
export const isTask = (e) => e.category === 'activity' && e.variant === 'task';
export const isParallel = (e) => e.category === 'gateway' && e.variant === 'parallel';
/**
 * Derive the BPMN data associations (dataInputAssociation / dataOutputAssociation)
 * from every activity's ioSpec. Drops any reference that doesn't resolve to a
 * declared DataObject (precise validation lives in the parser; this is defensive).
 */
export function dataAssociations(ast) {
    const known = new Set(ast.dataObjects.map((d) => d.id));
    const out = [];
    for (const el of ast.elements) {
        if (!el.ioSpec)
            continue;
        for (const obj of el.ioSpec.inputs) {
            if (known.has(obj))
                out.push({ activityId: el.id, direction: 'input', dataObject: obj });
        }
        for (const obj of el.ioSpec.outputs) {
            if (known.has(obj))
                out.push({ activityId: el.id, direction: 'output', dataObject: obj });
        }
    }
    return out;
}
